import { useState } from 'react';
import LoginPage from './components/LoginPage';
import Header from './components/Header';
import PostList from './components/PostList';
import PostDetail from './components/PostDetail';
import WritePost from './components/WritePost';
import { User, Post, Comment } from './types';
import { posts as initialPosts, comments as initialComments } from './data';

type View = 'home' | 'trending' | 'write' | 'detail';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<View>('home');
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [posts, setPosts] = useState<Post[]>(initialPosts);
  const [comments, setComments] = useState<Comment[]>(initialComments);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('home');
  };

  const handleViewChange = (view: 'home' | 'trending' | 'write') => {
    setCurrentView(view);
    setSelectedPostId(null);
  };

  const handleSelectPost = (postId: string) => {
    setSelectedPostId(postId);
    setCurrentView('detail');
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    setSelectedPostId(null);
  };

  const handleAddComment = (postId: string, content: string) => {
    if (!currentUser) return;

    const newComment: Comment = {
      id: Date.now().toString(),
      postId,
      author: currentUser,
      content,
      createdAt: new Date()
    };

    setComments([...comments, newComment]);
  };

  const handlePublishPost = (title: string, content: string, tags: string[]) => {
    if (!currentUser) return;

    const newPost: Post = {
      id: Date.now().toString(),
      title,
      content,
      author: currentUser,
      createdAt: new Date(),
      views: 0,
      likes: 0,
      tags
    };

    setPosts([newPost, ...posts]);
    setCurrentView('home');
  };

  const getTrendingPosts = () => {
    return [...posts].sort((a, b) => b.views - a.views).slice(0, 5);
  };

  const getPostComments = (postId: string) => {
    return comments.filter(c => c.postId === postId);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header
        currentUser={currentUser}
        onLogout={handleLogout}
        onLogin={() => setCurrentUser(null)}
        currentView={currentView === 'detail' ? 'home' : currentView}
        onViewChange={handleViewChange}
      />

      {!currentUser && <LoginPage onLogin={handleLogin} />}

      {currentUser && currentView === 'home' && (
        <PostList
          posts={posts}
          comments={comments}
          onSelectPost={handleSelectPost}
        />
      )}

      {currentUser && currentView === 'trending' && (
        <PostList
          posts={getTrendingPosts()}
          comments={comments}
          onSelectPost={handleSelectPost}
          isTrending
        />
      )}

      {currentUser && currentView === 'write' && (
        <WritePost
          currentUser={currentUser}
          onPublish={handlePublishPost}
        />
      )}

      {currentUser && currentView === 'detail' && selectedPostId && (
        <PostDetail
          post={posts.find(p => p.id === selectedPostId)!}
          comments={getPostComments(selectedPostId)}
          currentUser={currentUser}
          onBack={handleBackToHome}
          onAddComment={handleAddComment}
        />
      )}
    </div>
  );
}

export default App;
