export interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  avatar: string;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  author: User;
  createdAt: Date;
  views: number;
  likes: number;
  tags: string[];
}

export interface Comment {
  id: string;
  postId: string;
  author: User;
  content: string;
  createdAt: Date;
}
