import { useState } from 'react';
import { ArrowLeft, Eye, Heart, MessageCircle, Send } from 'lucide-react';
import { Post, Comment, User } from '../types';

interface PostDetailProps {
  post: Post;
  comments: Comment[];
  currentUser: User;
  onBack: () => void;
  onAddComment: (postId: string, content: string) => void;
}

export default function PostDetail({ post, comments, currentUser, onBack, onAddComment }: PostDetailProps) {
  const [commentText, setCommentText] = useState('');

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatCommentDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      onAddComment(post.id, commentText);
      setCommentText('');
    }
  };

  const renderContent = (content: string) => {
    return content.split('\n').map((line, index) => {
      if (line.startsWith('## ')) {
        return (
          <h2 key={index} className="text-2xl font-bold text-slate-900 mt-8 mb-4">
            {line.replace('## ', '')}
          </h2>
        );
      } else if (line.startsWith('```')) {
        return null;
      } else if (line.trim().startsWith('-') || line.trim().startsWith('1.')) {
        return (
          <li key={index} className="text-slate-700 leading-relaxed ml-6">
            {line.replace(/^[-\d.]\s*/, '')}
          </li>
        );
      } else if (line.includes('**')) {
        const parts = line.split('**');
        return (
          <p key={index} className="text-slate-700 leading-relaxed mb-4">
            {parts.map((part, i) =>
              i % 2 === 1 ? <strong key={i} className="font-semibold text-slate-900">{part}</strong> : part
            )}
          </p>
        );
      } else if (line.trim() === '') {
        return <div key={index} className="h-2" />;
      } else {
        return (
          <p key={index} className="text-slate-700 leading-relaxed mb-4">
            {line}
          </p>
        );
      }
    });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-slate-600 hover:text-slate-900 mb-8 transition"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back to posts</span>
        </button>

        <article className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-8 md:p-12">
            <div className="flex items-center space-x-4 mb-6">
              <img
                src={post.author.avatar}
                alt={post.author.username}
                className="w-14 h-14 rounded-full border-2 border-slate-100"
              />
              <div>
                <p className="font-semibold text-lg text-slate-900">{post.author.username}</p>
                <p className="text-slate-500">{formatDate(post.createdAt)}</p>
              </div>
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 leading-tight">
              {post.title}
            </h1>

            <div className="flex items-center space-x-6 mb-8 pb-8 border-b border-slate-200">
              <div className="flex items-center space-x-2 text-slate-600">
                <Eye className="w-5 h-5" />
                <span className="font-medium">{post.views} views</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-600">
                <Heart className="w-5 h-5" />
                <span className="font-medium">{post.likes} likes</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-600">
                <MessageCircle className="w-5 h-5" />
                <span className="font-medium">{comments.length} comments</span>
              </div>
            </div>

            <div className="prose prose-slate max-w-none">
              {renderContent(post.content)}
            </div>

            <div className="flex flex-wrap gap-2 mt-8 pt-8 border-t border-slate-200">
              {post.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-full hover:bg-slate-200 transition font-medium"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        </article>

        <div className="mt-8 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center">
              <MessageCircle className="w-6 h-6 mr-2" />
              Comments ({comments.length})
            </h2>

            <form onSubmit={handleSubmitComment} className="mb-8">
              <div className="flex items-start space-x-4">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.username}
                  className="w-10 h-10 rounded-full border-2 border-slate-100"
                />
                <div className="flex-1">
                  <textarea
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Share your thoughts..."
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent resize-none transition"
                    rows={3}
                    required
                  />
                  <button
                    type="submit"
                    className="mt-3 flex items-center space-x-2 px-4 py-2 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 transition"
                  >
                    <Send className="w-4 h-4" />
                    <span>Post Comment</span>
                  </button>
                </div>
              </div>
            </form>

            <div className="space-y-6">
              {comments.map((comment) => (
                <div key={comment.id} className="flex items-start space-x-4 p-4 bg-slate-50 rounded-lg">
                  <img
                    src={comment.author.avatar}
                    alt={comment.author.username}
                    className="w-10 h-10 rounded-full border-2 border-white"
                  />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <p className="font-semibold text-slate-900">{comment.author.username}</p>
                      <span className="text-slate-400">•</span>
                      <p className="text-sm text-slate-500">{formatCommentDate(comment.createdAt)}</p>
                    </div>
                    <p className="text-slate-700 leading-relaxed">{comment.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
