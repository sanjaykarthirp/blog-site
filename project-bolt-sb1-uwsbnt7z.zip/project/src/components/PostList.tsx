import { Post, Comment } from '../types';
import PostCard from './PostCard';

interface PostListProps {
  posts: Post[];
  comments: Comment[];
  onSelectPost: (postId: string) => void;
  isTrending?: boolean;
}

export default function PostList({ posts, comments, onSelectPost, isTrending }: PostListProps) {
  const getCommentCount = (postId: string) => {
    return comments.filter(c => c.postId === postId).length;
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {isTrending && (
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-slate-900 mb-2">Trending Posts</h1>
            <p className="text-slate-600 text-lg">Most popular articles in the community</p>
          </div>
        )}

        <div className="space-y-6">
          {posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              commentCount={getCommentCount(post.id)}
              onReadMore={() => onSelectPost(post.id)}
              isTrending={isTrending}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
