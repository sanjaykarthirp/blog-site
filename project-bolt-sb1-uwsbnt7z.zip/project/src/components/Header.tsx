import { PenTool, LogOut, TrendingUp, Home, CreditCard as Edit3, LogIn } from 'lucide-react';
import { User } from '../types';

interface HeaderProps {
  currentUser: User | null;
  onLogout: () => void;
  onLogin: () => void;
  currentView: 'home' | 'trending' | 'write';
  onViewChange: (view: 'home' | 'trending' | 'write') => void;
}

export default function Header({ currentUser, onLogout, onLogin, currentView, onViewChange }: HeaderProps) {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => currentUser && onViewChange('home')}
            className="flex items-center space-x-2 hover:opacity-80 transition"
          >
            <div className="bg-slate-900 p-2 rounded-lg">
              <PenTool className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900">Dev Blog</h1>
          </button>

          {currentUser && (
            <>
              <nav className="hidden md:flex items-center space-x-2">
                <button
                  onClick={() => onViewChange('home')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition ${
                    currentView === 'home'
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Home className="w-4 h-4" />
                  <span>Home</span>
                </button>

                <button
                  onClick={() => onViewChange('trending')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition ${
                    currentView === 'trending'
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>Trending</span>
                </button>

                <button
                  onClick={() => onViewChange('write')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition ${
                    currentView === 'write'
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Write</span>
                </button>
              </nav>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-3">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.username}
                    className="w-10 h-10 rounded-full border-2 border-slate-200"
                  />
                  <div className="hidden sm:block">
                    <p className="text-sm font-semibold text-slate-900">{currentUser.username}</p>
                  </div>
                </div>

                <button
                  onClick={onLogout}
                  className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </>
          )}

          {!currentUser && (
            <button
              onClick={onLogin}
              className="flex items-center space-x-2 px-4 py-2 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 transition"
            >
              <LogIn className="w-5 h-5" />
              <span>Sign In</span>
            </button>
          )}
        </div>

        {currentUser && (
          <nav className="flex md:hidden items-center space-x-2 mt-4">
            <button
              onClick={() => onViewChange('home')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                currentView === 'home'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Home className="w-4 h-4" />
              <span>Home</span>
            </button>

            <button
              onClick={() => onViewChange('trending')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                currentView === 'trending'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Trending</span>
            </button>

            <button
              onClick={() => onViewChange('write')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                currentView === 'write'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Edit3 className="w-4 h-4" />
              <span>Write</span>
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
