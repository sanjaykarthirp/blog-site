import { Eye, Heart, MessageCircle, TrendingUp } from 'lucide-react';
import { Post } from '../types';

interface PostCardProps {
  post: Post;
  commentCount: number;
  onReadMore: () => void;
  isTrending?: boolean;
}

export default function PostCard({ post, commentCount, onReadMore, isTrending }: PostCardProps) {
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <article className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-200 overflow-hidden">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <img
            src={post.author.avatar}
            alt={post.author.username}
            className="w-10 h-10 rounded-full border-2 border-slate-100"
          />
          <div>
            <p className="font-semibold text-slate-900">{post.author.username}</p>
            <p className="text-sm text-slate-500">{formatDate(post.createdAt)}</p>
          </div>
          {isTrending && (
            <div className="ml-auto">
              <div className="flex items-center space-x-1 bg-orange-50 text-orange-600 px-3 py-1 rounded-full text-sm font-medium">
                <TrendingUp className="w-4 h-4" />
                <span>Trending</span>
              </div>
            </div>
          )}
        </div>

        <h2 className="text-2xl font-bold text-slate-900 mb-3 hover:text-slate-700 transition cursor-pointer" onClick={onReadMore}>
          {post.title}
        </h2>

        <p className="text-slate-600 mb-4 line-clamp-3">
          {post.content.split('\n\n')[0].substring(0, 200)}...
        </p>

        <div className="flex flex-wrap gap-2 mb-4">
          {post.tags.map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 bg-slate-100 text-slate-700 text-sm rounded-full hover:bg-slate-200 transition"
            >
              #{tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2 text-slate-500">
              <Eye className="w-5 h-5" />
              <span className="text-sm font-medium">{post.views}</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-500">
              <Heart className="w-5 h-5" />
              <span className="text-sm font-medium">{post.likes}</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-500">
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{commentCount}</span>
            </div>
          </div>

          <button
            onClick={onReadMore}
            className="px-4 py-2 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 transition text-sm"
          >
            Read More
          </button>
        </div>
      </div>
    </article>
  );
}
