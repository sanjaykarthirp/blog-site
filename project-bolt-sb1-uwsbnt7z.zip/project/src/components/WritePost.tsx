import { useState } from 'react';
import { PenTool, Save } from 'lucide-react';
import { User } from '../types';

interface WritePostProps {
  currentUser: User;
  onPublish: (title: string, content: string, tags: string[]) => void;
}

export default function WritePost({ currentUser, onPublish }: WritePostProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handlePublish = () => {
    if (title.trim() && content.trim()) {
      onPublish(title, content, tags);
      setTitle('');
      setContent('');
      setTags([]);
      setTagInput('');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-8">
            <div className="flex items-center space-x-3 mb-8">
              <div className="bg-slate-900 p-3 rounded-lg">
                <PenTool className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Write a Post</h1>
                <p className="text-slate-600">Share your knowledge with the community</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 mb-6 p-4 bg-slate-50 rounded-lg">
              <img
                src={currentUser.avatar}
                alt={currentUser.username}
                className="w-12 h-12 rounded-full border-2 border-slate-200"
              />
              <div>
                <p className="font-semibold text-slate-900">Writing as</p>
                <p className="text-slate-600">{currentUser.username}</p>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <label htmlFor="title" className="block text-sm font-semibold text-slate-700 mb-2">
                  Title
                </label>
                <input
                  id="title"
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter an engaging title..."
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent text-lg transition"
                />
              </div>

              <div>
                <label htmlFor="content" className="block text-sm font-semibold text-slate-700 mb-2">
                  Content
                </label>
                <textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Write your post content here... You can use markdown-style formatting:

## Headings
Use ## for section headings

**Bold text**
Wrap text in ** for bold

- Bullet points
Start lines with - for lists

Share your insights and help others learn!"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent resize-none transition font-mono text-sm"
                  rows={16}
                />
              </div>

              <div>
                <label htmlFor="tags" className="block text-sm font-semibold text-slate-700 mb-2">
                  Tags
                </label>
                <div className="flex space-x-2 mb-3">
                  <input
                    id="tags"
                    type="text"
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                    placeholder="Add tags (press Enter)"
                    className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent transition"
                  />
                  <button
                    type="button"
                    onClick={handleAddTag}
                    className="px-6 py-3 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 transition"
                  >
                    Add
                  </button>
                </div>

                {tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-4 py-2 bg-slate-900 text-white rounded-full text-sm font-medium flex items-center space-x-2 cursor-pointer hover:bg-slate-800 transition"
                        onClick={() => handleRemoveTag(tag)}
                      >
                        <span>#{tag}</span>
                        <span className="text-slate-300 hover:text-white">×</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-200 flex justify-end space-x-4">
              <button
                onClick={handlePublish}
                disabled={!title.trim() || !content.trim()}
                className="flex items-center space-x-2 px-6 py-3 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
              >
                <Save className="w-5 h-5" />
                <span>Publish Post</span>
              </button>
            </div>
          </div>
        </div>

        <div className="mt-6 p-6 bg-blue-50 border border-blue-200 rounded-xl">
          <h3 className="font-semibold text-blue-900 mb-2">Formatting Tips</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Use <code className="bg-blue-100 px-2 py-0.5 rounded">## Heading</code> for section titles</li>
            <li>• Use <code className="bg-blue-100 px-2 py-0.5 rounded">**text**</code> for bold text</li>
            <li>• Start lines with <code className="bg-blue-100 px-2 py-0.5 rounded">-</code> or <code className="bg-blue-100 px-2 py-0.5 rounded">1.</code> for lists</li>
            <li>• Leave blank lines between paragraphs for better readability</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
