import { User, Post, Comment } from './types';

export const users: User[] = [
  {
    id: '1',
    username: 'sarah_dev',
    email: 'sarah@devblog.com',
    password: 'demo123',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=200'
  },
  {
    id: '2',
    username: 'john_coder',
    email: 'john@devblog.com',
    password: 'demo123',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=200'
  },
  {
    id: '3',
    username: 'emma_tech',
    email: 'emma@devblog.com',
    password: 'demo123',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=200'
  }
];

export const posts: Post[] = [
  {
    id: '1',
    title: 'Building Scalable React Applications in 2024',
    content: `React has evolved significantly over the years, and building scalable applications requires understanding modern patterns and best practices.

## Key Principles

When building large-scale React applications, consider these fundamental principles:

1. **Component Composition**: Break down your UI into small, reusable components
2. **State Management**: Choose the right tool for your needs (Context, Redux, Zustand)
3. **Code Splitting**: Lazy load components to improve initial load time
4. **Performance Optimization**: Use React.memo, useMemo, and useCallback wisely

## Modern Architecture

A well-structured React application typically follows a feature-based architecture:

- Organize by features, not by file types
- Keep related components, hooks, and utilities together
- Implement a clear separation of concerns

## Testing Strategy

Don't forget to test your components! Use React Testing Library for component tests and Playwright for end-to-end testing.

Building scalable applications is an ongoing journey. Stay curious and keep learning!`,
    author: users[0],
    createdAt: new Date('2024-03-10'),
    views: 2847,
    likes: 234,
    tags: ['React', 'JavaScript', 'Architecture']
  },
  {
    id: '2',
    title: 'TypeScript Tips: Advanced Type Patterns',
    content: `TypeScript's type system is incredibly powerful. Let's explore some advanced patterns that can make your code more type-safe and maintainable.

## Discriminated Unions

One of my favorite patterns is discriminated unions for handling different states:

\`\`\`typescript
type Result<T> =
  | { status: 'success'; data: T }
  | { status: 'error'; error: string }
  | { status: 'loading' };
\`\`\`

This pattern ensures you handle all possible states in your application.

## Conditional Types

Conditional types allow you to create types that depend on other types:

\`\`\`typescript
type NonNullable<T> = T extends null | undefined ? never : T;
\`\`\`

## Template Literal Types

With template literal types, you can create string-based types:

\`\`\`typescript
type EventName = \`on\${Capitalize<string>}\`;
\`\`\`

These patterns help catch bugs at compile time rather than runtime. Happy typing!`,
    author: users[1],
    createdAt: new Date('2024-03-12'),
    views: 1923,
    likes: 189,
    tags: ['TypeScript', 'Programming', 'Best Practices']
  },
  {
    id: '3',
    title: 'CSS Grid vs Flexbox: When to Use Each',
    content: `Both CSS Grid and Flexbox are powerful layout tools, but knowing when to use each can make your development process much smoother.

## Flexbox: One-Dimensional Layouts

Flexbox excels at:
- Navigation bars
- Card layouts in a row or column
- Centering content
- Distributing space between items

Use flexbox when you're working with a single dimension (either row or column).

## CSS Grid: Two-Dimensional Layouts

Grid is perfect for:
- Page layouts with header, sidebar, main content, and footer
- Complex gallery layouts
- Any layout where you need precise control over both rows and columns

## The Reality

In practice, you'll often use both together! Use Grid for the overall page layout and Flexbox for components within grid areas.

## Pro Tip

Start with Flexbox for simpler layouts. When you find yourself nesting multiple flex containers or struggling with alignment, that's your cue to consider Grid.

Remember: there's no wrong choice, only what works best for your specific use case!`,
    author: users[2],
    createdAt: new Date('2024-03-14'),
    views: 3421,
    likes: 312,
    tags: ['CSS', 'Web Design', 'Frontend']
  },
  {
    id: '4',
    title: 'Understanding JavaScript Closures with Real Examples',
    content: `Closures are a fundamental concept in JavaScript that every developer should understand. They're not as scary as they seem!

## What is a Closure?

A closure is a function that has access to variables in its outer (enclosing) scope, even after the outer function has returned.

## Real-World Example: Private Variables

\`\`\`javascript
function createCounter() {
  let count = 0;

  return {
    increment: () => ++count,
    decrement: () => --count,
    getCount: () => count
  };
}

const counter = createCounter();
counter.increment(); // 1
counter.increment(); // 2
\`\`\`

The \`count\` variable is private - you can't access it directly from outside!

## Practical Uses

Closures are everywhere in JavaScript:
- Event handlers
- Callbacks
- Higher-order functions
- Module patterns

## Common Pitfall

Be careful with closures in loops! This is a classic gotcha that has bitten many developers.

Understanding closures will level up your JavaScript skills significantly!`,
    author: users[0],
    createdAt: new Date('2024-03-15'),
    views: 2156,
    likes: 198,
    tags: ['JavaScript', 'Programming', 'Tutorial']
  },
  {
    id: '5',
    title: 'Modern Web Performance Optimization Techniques',
    content: `Performance is crucial for user experience. Let's explore modern techniques to make your web applications blazingly fast.

## Core Web Vitals

Focus on these three metrics:
1. **LCP (Largest Contentful Paint)**: Load performance
2. **FID (First Input Delay)**: Interactivity
3. **CLS (Cumulative Layout Shift)**: Visual stability

## Optimization Strategies

### Image Optimization
- Use WebP format
- Implement lazy loading
- Serve responsive images with srcset
- Consider using a CDN

### Code Splitting
Break your JavaScript bundle into smaller chunks that load on demand:

\`\`\`javascript
const Component = lazy(() => import('./Component'));
\`\`\`

### Caching Strategies
Implement proper caching headers and use service workers for offline support.

## Measuring Performance

Use tools like:
- Lighthouse
- WebPageTest
- Chrome DevTools Performance tab

## The 80/20 Rule

Focus on the optimizations that give you the biggest impact. Don't optimize prematurely!

Remember: a fast website is a successful website. Your users will thank you!`,
    author: users[1],
    createdAt: new Date('2024-03-16'),
    views: 2891,
    likes: 267,
    tags: ['Performance', 'Web Development', 'Optimization']
  }
];

export const comments: Comment[] = [
  {
    id: '1',
    postId: '1',
    author: users[1],
    content: 'Great article! The component composition section really helped me understand how to structure my React app better.',
    createdAt: new Date('2024-03-10T14:30:00')
  },
  {
    id: '2',
    postId: '1',
    author: users[2],
    content: 'Thanks for sharing these insights. Would love to see more about state management patterns!',
    createdAt: new Date('2024-03-10T16:45:00')
  },
  {
    id: '3',
    postId: '2',
    author: users[0],
    content: 'The discriminated unions pattern is a game changer. I use it everywhere now!',
    createdAt: new Date('2024-03-12T10:20:00')
  },
  {
    id: '4',
    postId: '2',
    author: users[2],
    content: 'Could you explain more about template literal types? I find them a bit confusing.',
    createdAt: new Date('2024-03-12T15:30:00')
  },
  {
    id: '5',
    postId: '3',
    author: users[1],
    content: 'This cleared up so much confusion I had about Grid vs Flexbox. Thank you!',
    createdAt: new Date('2024-03-14T09:15:00')
  },
  {
    id: '6',
    postId: '3',
    author: users[0],
    content: 'Love the practical approach. Using both together is definitely the way to go.',
    createdAt: new Date('2024-03-14T11:40:00')
  },
  {
    id: '7',
    postId: '4',
    author: users[2],
    content: 'Finally understand closures! The counter example made it click for me.',
    createdAt: new Date('2024-03-15T13:25:00')
  },
  {
    id: '8',
    postId: '5',
    author: users[0],
    content: 'These optimization tips are gold. Implemented lazy loading and saw immediate improvements!',
    createdAt: new Date('2024-03-16T16:50:00')
  }
];
